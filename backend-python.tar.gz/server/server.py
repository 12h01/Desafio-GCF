import os

from .routes import (
    index,
    scoreboard,

    search,
    weather,
    new_record
)

import aiohttp_cors
from aiohttp import web

application = web.Application()
routes = web.RouteTableDef()

routes.get("/")(index)
routes.get("/scoreboard")(scoreboard)

routes.post("/search")(search)
routes.post("/weather")(weather)
routes.post("/new_record")(new_record)

application.add_routes(routes)
application.router.add_static("/assets", f"{os.getcwd()}/client/assets")

cors = aiohttp_cors.setup(
    app=application,
    defaults={
        "*": aiohttp_cors.ResourceOptions(
            allow_credentials=True,
            expose_headers="*",
            allow_headers="*"
        )
    }
)

for route in application.router.routes():
    cors.add(route)
