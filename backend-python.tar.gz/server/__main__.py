from os import chdir
from .server import application
from aiohttp.web import run_app

def main():
    run_app(application, port=8585)


if __name__ == "__main__":
    main()
