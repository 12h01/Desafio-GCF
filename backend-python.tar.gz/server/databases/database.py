from ..utilities import (
    run_in_executor,
    request_connection
)

import os
from sqlite3 import Cursor, connect


class Database:
    PATH = "databases/database.db"

    def __init__(self):
        path = self.PATH.split("/")
        folders, file = path[:-1], path[-1]

        path = ""
        for folder in folders:
            path += folder + "/"

            if not os.path.exists(path):
                os.mkdir(path)

        if not os.path.exists(self.PATH):
            open(self.PATH, "w").close()

        self.initialization()

    @property
    def sql_connection(self) -> tuple:
        connection = connect(self.PATH)
        return connection, connection.cursor()

    @staticmethod
    def execute(cursor: Cursor, request: str, params: tuple = tuple()) -> list:
        cursor.execute(request, params)
        return cursor.fetchall()

    @staticmethod
    def executemany(cursor: Cursor, request: str, params: tuple) -> list:
        cursor.executemany(request, params)
        return cursor.fetchall()

    @staticmethod
    def executescript(cursor: Cursor, request: str) -> list:
        cursor.executescript(request)
        return cursor.fetchall()

    @request_connection
    def initialization(self, cursor: Cursor):

        self.executescript(
            cursor,
            """
            CREATE TABLE IF NOT EXISTS scoreboard (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                rating INTEGER NOT NULL,
                city TEXT NOT NULL,
                weather INTEGER NOT NULL,
                time TEXT NOT NULL
            )
            """
        )

    @run_in_executor
    @request_connection
    def add_rating(self, cursor: Cursor, name: str, rating: int, city: str, weather: int, time: str):

        self.execute(
            cursor,
            """
            INSERT INTO scoreboard (name, rating, city, weather, time) VALUES
             (?, ?, ?, ?, ?)
            """,
            (name, rating, city, weather, time)
        )

    @run_in_executor
    @request_connection
    def get_scoreboard(self, cursor: Cursor) -> list:

        result = self.execute(
            cursor,
            """
            SELECT * FROM scoreboard
            """
        )

        return result
