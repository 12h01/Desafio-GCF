from .database import Database

database = Database()
