import os
import sys
import sqlite3

PATH = "databases/database.db"

if not os.path.exists(PATH):
    print(f"Database doesn't exist:\n{PATH}")
    sys.exit(1)

connection = sqlite3.connect(PATH)
cursor = connection.cursor()

result = [["ID", "Name", "Rating", "City", "Weather", "Time"]]
result = [*result, *[list(entity) for entity in cursor.execute("SELECT * FROM scoreboard").fetchall()]]
max_lengths = [max([len(str(entity[0])) + 2 for entity in zip(el[index] for el in result)]) for index in range(len(result[0]))]
string = "\n".join(["".join([str(el).ljust(max_lengths[index], " ") for index, el in enumerate(entity)]) for entity in result])

cursor.close()
connection.close()
print(string)
