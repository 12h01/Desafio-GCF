import asyncio
from concurrent.futures import ThreadPoolExecutor


def run_in_executor(function):

    async def wrapper(*args):
        event_loop = asyncio.get_running_loop()
        with ThreadPoolExecutor() as executor:
            return await event_loop.run_in_executor(
                executor, function, *args
            )

    return wrapper
