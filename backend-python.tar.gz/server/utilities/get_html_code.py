

def get_html_code(path: str) -> str:
    with open(path, "r") as file:
        return file.read()
