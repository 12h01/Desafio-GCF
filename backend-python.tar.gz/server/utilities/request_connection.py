

def request_connection(function):

    def wrapper(self, *args):
        connection, cursor = self.sql_connection
        result = function(self, cursor, *args)
        connection.commit()

        cursor.close()
        connection.close()

        return result

    return wrapper
