import orjson

from ..utilities import run_in_executor
from bs4 import BeautifulSoup as Parser
from aiohttp import ClientSession
from orjson import loads


class Weather:
    SEARCH_URL = "https://suggest-maps.yandex.com/suggest-geo?lang=pt_BR&search_type=weather_v2&client_id=weather_v2&part={query}&pos={length}"
    WEATHER_URL = "https://yandex.com/weather?"

    def __init__(self):
        self.requests_session = None

    async def get_requests_session(self) -> ClientSession:
        if self.requests_session is None:
            self.requests_session = ClientSession()

        return self.requests_session

    async def close_requests_session(self):
        requests_session = await self.get_requests_session()
        await requests_session.close()

    async def _get_html_code(self, url: str) -> str:
        requests_session = await self.get_requests_session()

        async with requests_session.get(url) as response:
            return await response.text()

    async def search(self, query: str) -> list:
        requests_session = await self.get_requests_session()

        url = self.SEARCH_URL.format(query=query, length=len(query))
        async with requests_session.get(url) as response:
            response_json = await response.json(loads=loads)

        cities = [{
            "city_name": ", ".join(city["name"].split(", ")[:-1]).replace("State of ", ""),
            "city_url": f"lat={city['lat']}&lon={city['lon']}"
        } for city in response_json[1] if "lat" in city and "lon" in city]

        result = {}

        for city in cities:
            result.setdefault(city['city_name'], city['city_url'])

        return result

    async def get_weather(self, city_link: str) -> dict:
        html_code = await self._get_html_code(self.WEATHER_URL + city_link + "&lang=pt")
        return await self._parse_weather(html_code)

    @run_in_executor
    def _parse_weather(self, html_code: str) -> dict:
        parser, result = Parser(html_code, features="html.parser"), dict()
        result["main_title"] = parser.find(id="main_title").text
        result["time_now"] = parser.find(class_="fact__time").text.strip().split(" ")[-1]
        result["degree"] = parser.find(class_="temp__value_with-unit").text
        result["anchor"] = parser.find(class_="link__condition").text
        step = parser.find(class_="term term_orient_h fact__feels-like")
        result["feels_like"] = step.find(class_='temp__value_with-unit').text
        result["wind"] = parser.find(class_="term term_orient_v fact__wind-speed").find(class_="term__value").get("aria-label")
        result["humidity"] = parser.find(class_="term term_orient_v fact__humidity").find(class_="term__value").get("aria-label")
        result["pressure"] = parser.find(class_="term term_orient_v fact__pressure").find(class_="term__value").get("aria-label")
        result["rainfall"] = parser.find(class_="maps-widget-fact__title").text
        result["next_days"] = [{
            "weekday": next_day.find(class_="forecast-briefly__name").text,
            "date": next_day.find(class_="time forecast-briefly__date").text,
            "degree": next_day.find(class_="temp__value temp__value_with-unit").text,
            "prediction": next_day.find(class_="forecast-briefly__condition").text
        } for next_day in parser.find_all(class_="forecast-briefly__day")[2:9]]
        return result
