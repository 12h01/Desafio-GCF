from .session import Weather

weather_manager = Weather()
