from .dumps import dumps
from aiohttp.web import Response, json_response


def success(data: dict) -> Response:
    return json_response(
        status=200,
        data={
            "status": 200,
            "data": data
        },
        content_type="application/json",
        dumps=dumps
    )
