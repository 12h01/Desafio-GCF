import orjson


def dumps(data: dict) -> str:
    return orjson.dumps(data).decode()
