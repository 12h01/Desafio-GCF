from .dumps import dumps
from aiohttp.web import Response, json_response


def bad_request() -> Response:
    return json_response(
        status=400,
        data={
            "status": 400,
            "message": "Bad request."
        },
        content_type="application/json",
        dumps=dumps
    )
