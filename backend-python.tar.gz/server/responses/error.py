from .dumps import dumps
from aiohttp.web import Response, json_response


def error() -> Response:
    return json_response(
        status=418,
        data={
            "status": 418,
            "message": "Some of params might be missing."
        },
        content_type="application/json",
        dumps=dumps
    )
