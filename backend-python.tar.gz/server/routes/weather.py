from ..weather import weather_manager
from ..responses import bad_request, error, success

from orjson import JSONDecodeError, loads
from aiohttp.web import Request, Response


async def weather(request: Request) -> Response:
    print(request)

    try:
        request_json = await request.json(loads=loads)
    except JSONDecodeError:
        return bad_request()

    if "city_link" not in request_json:
        return error()

    city_link = request_json["city_link"]
    result = await weather_manager.get_weather(city_link)
    return success(result)
