from ..weather import weather_manager
from ..responses import bad_request, error, success

from orjson import JSONDecodeError, loads
from aiohttp.web import Request, Response


async def search(request: Request) -> Response:
    print(request)

    try:
        request_json = await request.json(loads=loads)
    except JSONDecodeError:
        return bad_request()

    if "query" not in request_json:
        return error()

    query = request_json["query"]
    result = await weather_manager.search(query)
    return success(result)
