from ..utilities import get_html_code
from aiohttp.web import Request, Response

HTML_PATH = "client/index.html"


async def index(request: Request) -> Response:
    print(request)

    return Response(
        text=get_html_code(HTML_PATH),
        content_type="text/html"
    )
