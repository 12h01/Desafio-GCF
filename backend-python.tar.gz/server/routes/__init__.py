from .index import index
from .scoreboard import scoreboard

from .search import search
from .weather import weather
from .new_record import new_record
