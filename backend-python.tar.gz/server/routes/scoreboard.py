from ..utilities import get_html_code
from ..databases import database

from aiohttp.web import Request, Response
from jinja2 import Template

HTML_PATH = "client/scoreboard.html"


async def scoreboard(request: Request) -> Response:
    print(request)

    html_code = get_html_code(HTML_PATH)
    data = await database.get_scoreboard()

    html_code = Template(html_code).render(data=data)
    return Response(
        text=html_code,
        content_type="text/html"
    )

