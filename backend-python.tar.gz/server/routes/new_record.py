from ..databases import database
from ..responses import bad_request, error

from orjson import JSONDecodeError, loads
from aiohttp.web import Request, Response


async def new_record(request: Request) -> Response:
    print(request)

    try:
        request_json = await request.json(loads=loads)
    except JSONDecodeError:
        return bad_request()

    try:
        name = request_json["name"]
        rating = request_json["rating"]
        city = request_json["city"]
        weather = request_json["weather"]
        time = request_json["time"]
    except KeyError:
        return error()

    await database.add_rating(name, rating, city, weather, time)
    return Response(status=200)
